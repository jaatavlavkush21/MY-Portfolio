/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import WhyChooseMe from './components/WhyChooseMe';
import Portfolio from './components/Portfolio';
import Process from './components/Process';
import ClientTypes from './components/ClientTypes';
import Contact from './components/Contact';
import Footer from './components/Footer';
import FloatingWhatsApp from './components/FloatingWhatsApp';

export default function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [selectedBusinessType, setSelectedBusinessType] = useState('Local Shop');

  // Track active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'services', 'portfolio', 'process', 'clients', 'contact'];
      const scrollPosition = window.scrollY + 180; // offset for nav bar

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;

          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Set prepopulated business type from Services
  const handleSelectService = (serviceTitle: string) => {
    // Map service category to the Contact form options
    if (serviceTitle.includes('Beauty Parlour') || serviceTitle.includes('Salon')) {
      setSelectedBusinessType('Beauty Parlour');
    } else if (serviceTitle.includes('E-Commerce')) {
      setSelectedBusinessType('Fashion Boutique');
    } else if (serviceTitle.includes('Business Website')) {
      setSelectedBusinessType('Local Office / Company');
    } else {
      setSelectedBusinessType('Other Business Type');
    }
  };

  // Set prepopulated business type from target clients bento grid
  const handleSelectClientType = (clientLabel: string) => {
    if (clientLabel.includes('Shops')) {
      setSelectedBusinessType('Local Shop');
    } else if (clientLabel.includes('Beauty')) {
      setSelectedBusinessType('Beauty Parlour');
    } else if (clientLabel.includes('Salons') || clientLabel.includes('Hair')) {
      setSelectedBusinessType('Hair Salon');
    } else if (clientLabel.includes('Boutiques')) {
      setSelectedBusinessType('Fashion Boutique');
    } else if (clientLabel.includes('Restaurants')) {
      setSelectedBusinessType('Restaurant / Cafe');
    } else if (clientLabel.includes('Offices')) {
      setSelectedBusinessType('Local Office / Company');
    } else if (clientLabel.includes('Coaching')) {
      setSelectedBusinessType('Coaching Center / Tuition');
    } else {
      setSelectedBusinessType('Other Business Type');
    }
  };

  return (
    <div className="bg-[#070b13] text-white min-h-screen font-sans selection:bg-purple-500/30 selection:text-white antialiased overflow-x-hidden relative">
      
      {/* Absolute Background Ambient Blur Blobs */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute top-[30%] left-0 w-[450px] h-[450px] bg-purple-500/5 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute bottom-[20%] right-0 w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* Global Navbar */}
      <Navbar activeSection={activeSection} />

      {/* Core Landing Page Sections */}
      <main id="main-content-flow">
        <Hero />
        <About />
        <Services onSelectService={handleSelectService} />
        <WhyChooseMe />
        <Portfolio />
        <Process />
        <ClientTypes onSelectClientType={handleSelectClientType} />
        <Contact selectedBusinessType={selectedBusinessType} />
      </main>

      {/* Global Footer */}
      <Footer />

      {/* Persistent Floating WhatsApp Help Node */}
      <FloatingWhatsApp />
    </div>
  );
}
