/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Sparkles } from 'lucide-react';
import { DEVELOPER_INFO } from '../data';

export default function FloatingWhatsApp() {
  const defaultMessage = "Hello Wangdu Lavkush, I am visiting your portfolio website and would like to discuss building a custom website for my business.";
  const encodedMsg = encodeURIComponent(defaultMessage);
  const finalUrl = `https://wa.me/917408610380?text=${encodedMsg}`;

  return (
    <div className="fixed bottom-6 right-6 z-40" id="floating-whatsapp-container">
      {/* Mini notification label pulsing */}
      <div className="absolute -top-10 right-0 glass px-3 py-1 rounded-full border border-emerald-500/30 shadow-[0_4px_12px_rgba(16,185,129,0.15)] flex items-center space-x-1 whitespace-nowrap text-[10px] font-mono text-emerald-400 pointer-events-none animate-bounce">
        <Sparkles className="h-3 w-3 text-emerald-400 animate-pulse" />
        <span>Chat with Wangdu</span>
      </div>

      <motion.a
        href={finalUrl}
        target="_blank"
        rel="noopener noreferrer"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="flex items-center justify-center h-14 w-14 rounded-full bg-gradient-to-tr from-emerald-500 to-green-600 text-white shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/45 cursor-pointer border border-white/10"
        title="Chat on WhatsApp"
        id="floating-whatsapp-trigger"
      >
        <MessageCircle className="h-7 w-7 animate-pulse" />
      </motion.a>
    </div>
  );
}
