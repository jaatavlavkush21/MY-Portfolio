/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Instagram, Linkedin, Github, MessageCircle, Code, ArrowUp } from 'lucide-react';
import { DEVELOPER_INFO } from '../data';

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const currentYear = 2026;

  return (
    <footer className="bg-[#070b13] border-t border-white/5 py-12 relative overflow-hidden" id="main-footer">
      {/* Small background dot grid */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 md:gap-8">
          
          {/* Logo Brand Footer */}
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-gradient-to-tr from-blue-500 to-purple-600">
              <Code className="h-4 w-4 text-white" />
            </div>
            <div className="text-left">
              <span className="font-display font-bold text-white text-sm block">
                {DEVELOPER_INFO.name}
              </span>
              <span className="text-[9px] text-slate-500 font-mono block tracking-wider">
                PROFESSIONAL WEB PORTFOLIO
              </span>
            </div>
          </div>

          {/* Social Icons row */}
          <div className="flex items-center space-x-4" id="socials-container">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-slate-400 hover:text-white hover:border-white/15 hover:bg-gradient-to-tr hover:from-pink-500/20 hover:to-orange-500/20 transition-all cursor-pointer"
              title="Instagram Profile"
            >
              <Instagram className="h-4.5 w-4.5" />
            </a>

            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-slate-400 hover:text-white hover:border-white/15 hover:bg-gradient-to-tr hover:from-blue-600/20 hover:to-cyan-600/20 transition-all cursor-pointer"
              title="LinkedIn Profile"
            >
              <Linkedin className="h-4.5 w-4.5" />
            </a>

            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-slate-400 hover:text-white hover:border-white/15 hover:bg-gradient-to-tr hover:from-slate-800/25 hover:to-slate-700/20 transition-all cursor-pointer"
              title="GitHub Profile"
            >
              <Github className="h-4.5 w-4.5" />
            </a>

            <a
              href={DEVELOPER_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-slate-400 hover:text-white hover:border-white/15 hover:bg-gradient-to-tr hover:from-emerald-500/20 hover:to-teal-500/20 transition-all cursor-pointer"
              title="Direct WhatsApp"
            >
              <MessageCircle className="h-4.5 w-4.5" />
            </a>
          </div>

          {/* Copyright and Back to Top */}
          <div className="flex items-center space-x-6 text-xs text-slate-500 font-mono">
            <span>© {currentYear} {DEVELOPER_INFO.name} | Web Developer</span>
            
            <button
              onClick={handleScrollToTop}
              className="p-2 rounded-lg bg-white/5 border border-white/5 hover:border-white/10 hover:text-white text-slate-400 transition-all cursor-pointer flex items-center"
              title="Scroll to Top"
            >
              <ArrowUp className="h-3.5 w-3.5" />
            </button>
          </div>

        </div>
      </div>
    </footer>
  );
}
